# Fluid Notifications

Liquid-glass notifications that flow out of the camera cut-out (Samsung / Android 12+).
The animation follows the reference video frame by frame:

1. a white ring pops up around the camera,
2. a drop slides out of it and spreads into the card on a soft spring (the card stays joined to the
   camera by a smooth liquid "neck"),
3. the text un-blurs, then the Reply / Mark as read pills slide in,
4. closing: text fades -> card flattens into a pill -> is sucked back into the camera -> the ring fades.

Works with **every app**: Telegram, WhatsApp, SMS / Messages, Signal, mail, calendar, banks...
Chat apps are read through their MessagingStyle data, so you see the sender and the newest message
(group chats show "Sender: text"), plus the contact photo when the app provides one.
Several notifications at once are queued and shown one after another.

## Get the APK with GitHub (no Android Studio needed)
1. Create a new repository on github.com (empty, no README).
2. Upload **the contents of this folder** (not the folder itself) so that `settings.gradle.kts` and
   `.github/workflows/build.yml` are at the top level of the repo.
   Tip: if the web uploader skips the hidden `.github` folder, use *Add file -> Create new file*,
   type `.github/workflows/build.yml` as the name and paste the file contents.
3. Open the **Actions** tab -> *Build APK* -> wait ~3-5 minutes (it also starts automatically on every push;
   you can start it by hand with *Run workflow*).
4. Open the finished run -> **Artifacts** -> `FluidNotifications-apk` -> download the zip -> install `FluidNotifications.apk`.
   (Allow "install unknown apps" for your browser/file manager.)

For a permanent download link: create a tag like `v1.0` (Releases -> *Draft a new release* -> new tag `v1.0`);
the workflow attaches the APK to the release.

## First run
1. Open the app and switch on: Notification access, Display over other apps, Battery -> Unrestricted.
   The home screen shows a live preview and green "On" chips when everything is ready.
2. Samsung: Settings -> Notifications -> Notification pop-up style -> Brief, to avoid double pop-ups.
3. **Apps**: every app is allowed by default; switch off the ones you don't want.
4. **Test lab**: fake Telegram / WhatsApp / SMS notifications (use the delay to go to the home screen),
   or send a REAL notification through the whole pipeline.
5. Tune everything in **Settings** with the live preview pinned on top.

## Notes
* The overlay uses "Display over other apps", so it is shown over normal apps and the home screen,
  but Android does not allow third-party overlays on top of the lock screen.
* Silent notifications and Do Not Disturb are respected by default (both can be changed in Settings -> Behaviour).

## v3
- Incoming calls (WhatsApp, Telegram, Phone...) get **Answer / Decline** buttons. Look and ring time: Settings → Calls.
- Test lab → **Test call**: fake overlay calls and REAL call notifications (CallStyle and classic buttons).
- **System pop-ups** screen: one button to turn every app's own pop-up off / on
  (needs a one-time `adb shell pm grant com.example.fluidnotif android.permission.WRITE_SECURE_SETTINGS`).
- Smoother animation, Test lab no longer stacks/replays old overlays, diagnostics log in the Test lab.

## v5
- Landscape (video, games): the card drops from the top edge, centred. Settings → Landscape: on/off and width.
