package com.example.fluidnotif

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast

/** Receives the Answer / Decline taps of the REAL test call notification from the Test lab. */
class CallTestReceiver : BroadcastReceiver() {
    companion object {
        const val ANSWER = "com.example.fluidnotif.TEST_ANSWER"
        const val DECLINE = "com.example.fluidnotif.TEST_DECLINE"
        const val NOTIF_ID = 777
    }

    override fun onReceive(context: Context, intent: Intent) {
        val msg = if (intent.action == ANSWER) "Test call: ANSWERED ✓" else "Test call: DECLINED ✕"
        Toast.makeText(context.applicationContext, msg, Toast.LENGTH_SHORT).show()
        context.getSystemService(NotificationManager::class.java).cancel(NOTIF_ID)
    }
}
