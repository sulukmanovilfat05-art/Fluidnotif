package com.example.fluidnotif

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Person
import android.app.RemoteInput
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class TestActivity : BaseActivity() {

    private val h = Handler(Looper.getMainLooper())
    private lateinit var delay: EditText
    private lateinit var fApp: EditText
    private lateinit var fTitle: EditText
    private lateinit var fText: EditText
    private lateinit var fReply: Switch
    private lateinit var fCaller: EditText
    private lateinit var logView: TextView
    private var pendingFire: Runnable? = null
    private var notifId = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(topBar("Test lab"))

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpI(16f), 0, dpI(16f), dpI(36f))
        }

        fun field(box: LinearLayout, hint: String, init: String): EditText {
            val e = EditText(this).apply {
                this.hint = hint
                setText(init)
                textSize = 15.5f
                setTextColor(th.text)
                setHintTextColor(th.sub)
                setSingleLine()
                background = th.round(th.chip, 14f)
                setPadding(dpI(16f), 0, dpI(16f), 0)
            }
            box.addView(e, LinearLayout.LayoutParams(MATCH, dpI(48f)).apply {
                setMargins(dpI(12f), dpI(6f), dpI(12f), dpI(6f))
            })
            return e
        }

        col.addView(label(
            "Fake notifications to try your settings. Set a delay, tap a scenario, then go to the home screen " +
                "and watch it flow out of the camera.", 13.5f, th.sub
        ).apply { setPadding(dpI(6f), dpI(4f), dpI(6f), dpI(4f)) })

        col.addView(sectionHeader("Delay before showing (seconds)"))
        val dcard = card()
        delay = field(dcard, "seconds", "3").apply { inputType = InputType.TYPE_CLASS_NUMBER }
        col.addView(dcard)

        col.addView(sectionHeader("Test call"))
        val callCard = card()
        fCaller = field(callCard, "Caller name", "Mom")
        callCard.addView(divider())
        callCard.addView(tileRow("📞", 0xFF25D366.toInt(), "Fake call · WhatsApp style",
            "Overlay only. Tap Answer / Decline to try it", null) {
            fire(Fake("WhatsApp", caller(), "Incoming voice call", 0xFF25D366.toInt(), false, "calling", true))
        })
        callCard.addView(divider())
        callCard.addView(tileRow("📞", 0xFF2AABEE.toInt(), "Fake call · Telegram style",
            "Overlay only", null) {
            fire(Fake("Telegram", caller(), "Incoming call", 0xFF2AABEE.toInt(), false, "calling", true))
        })
        callCard.addView(divider())
        callCard.addView(tileRow("🔔", 0xFF5B6CFF.toInt(), "REAL call notification · system style",
            "Goes through the whole pipeline (CallStyle, like Telegram)", null) { sendRealCall(true) })
        callCard.addView(divider())
        callCard.addView(tileRow("🔔", 0xFF2BB673.toInt(), "REAL call notification · two buttons",
            "Goes through the whole pipeline (classic actions, like WhatsApp)", null) { sendRealCall(false) })
        callCard.addView(divider())
        callCard.addView(tileRow("✕", 0xFFE5483D.toInt(), "Stop test call", null, null) {
            getSystemService(NotificationManager::class.java).cancel(CallTestReceiver.NOTIF_ID)
            OverlayController.dismiss()
        })
        col.addView(callCard)

        col.addView(sectionHeader("Quick scenarios"))
        val scen = card()
        var firstScen = true
        Fakes.scenarios.filter { !it.isCall }.forEach { f ->
            if (!firstScen) scen.addView(divider())
            firstScen = false
            scen.addView(tileRow(f.app.take(1), f.color, f.app, f.title, null) { fire(f) })
        }
        col.addView(scen)

        col.addView(sectionHeader("Custom"))
        val ccard = card()
        fApp = field(ccard, "App name", "Telegram")
        fTitle = field(ccard, "Title", "Sam")
        fText = field(ccard, "Message", "Are we still on for lunch today?")
        fReply = Switch(this).apply { isChecked = true }
        ccard.addView(switchRow("Can reply", true) { fReply.isChecked = it })
        col.addView(ccard)
        col.addView(space(10f))
        col.addView(button("Show custom fake overlay", true) { fire(custom()) },
            LinearLayout.LayoutParams(MATCH, WRAP))

        col.addView(sectionHeader("More"))
        val more = card()
        more.addView(tileRow("⚡", 0xFFF2994A.toInt(), "Burst",
            "3 notifications in a row (tests the queue)", null) {
            Fakes.scenarios.take(3).forEachIndexed { i, f -> fire(f, extraMs = i * 600L) }
        })
        more.addView(divider())
        more.addView(tileRow("🔔", 0xFF5B6CFF.toInt(), "Send a REAL notification",
            "Goes through the whole pipeline, like Telegram would", null) { sendReal(custom()) })
        more.addView(divider())
        more.addView(tileRow("✕", 0xFFE5483D.toInt(), "Dismiss current overlay", null, null) {
            OverlayController.dismiss()
        })
        col.addView(more)

        col.addView(sectionHeader("What the app sees (diagnostics)"))
        val diag = card()
        logView = TextView(this).apply {
            textSize = 11f
            typeface = Typeface.MONOSPACE
            setTextColor(th.text)
            setTextIsSelectable(true)
            setPadding(dpI(14f), dpI(12f), dpI(14f), dpI(8f))
        }
        diag.addView(logView)
        col.addView(diag)
        col.addView(space(10f))
        val logBtns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        logBtns.addView(button("Refresh", false) { refreshLog() },
            LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dpI(6f) })
        logBtns.addView(button("Copy", true) {
            getSystemService(ClipboardManager::class.java)
                .setPrimaryClip(ClipData.newPlainText("log", NotifLog.dump()))
            Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dpI(6f); marginEnd = dpI(6f) })
        logBtns.addView(button("Clear", false) { NotifLog.clear(); refreshLog() },
            LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dpI(6f) })
        col.addView(logBtns, LinearLayout.LayoutParams(MATCH, WRAP))
        col.addView(label(
            "Every real notification from other apps is listed here with what the app decided. " +
                "If a call does not show up, tap Copy right after it rang and send it to me.",
            12.5f, th.sub
        ).apply { setPadding(dpI(8f), dpI(10f), dpI(8f), 0) })

        setPage(scroller(col))
        refreshLog()
    }

    override fun onResume() {
        super.onResume()
        if (::logView.isInitialized) refreshLog()
    }

    private fun refreshLog() { logView.text = NotifLog.dump() }

    private fun caller() = fCaller.text.toString().ifBlank { "Mom" }

    private fun custom() = Fake(
        fApp.text.toString().ifBlank { "App" },
        fTitle.text.toString(),
        fText.text.toString(),
        0xFF8E5BFF.toInt(),
        fReply.isChecked
    )

    private fun delayMs(): Long = (delay.text.toString().toLongOrNull() ?: 0L) * 1000L

    private fun fire(f: Fake, extraMs: Long = 0L) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Grant \"Display over other apps\" first", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        val total = delayMs() + extraMs
        if (total >= 1000 && extraMs == 0L) {
            Toast.makeText(this, "Showing in ${total / 1000} s — go to the home screen", Toast.LENGTH_SHORT).show()
        }
        val data = f.toData(this)
        val single = extraMs == 0L
        if (single) pendingFire?.let { h.removeCallbacks(it) }
        val run = Runnable { OverlayController.show(applicationContext, data, replace = single) }
        if (single) pendingFire = run
        h.postDelayed(run, total)
    }

    private fun sendReal(f: Fake) {
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            return
        }
        val total = delayMs()
        Toast.makeText(this, "Real notification in ${total / 1000} s", Toast.LENGTH_SHORT).show()
        h.postDelayed({
            val nm = getSystemService(NotificationManager::class.java)
            // Default importance = shows in the shade, no system banner on top of ours.
            nm.createNotificationChannel(
                NotificationChannel("test_quiet", "Test (quiet)", NotificationManager.IMPORTANCE_DEFAULT).apply {
                    setSound(null, null)
                    enableVibration(false)
                }
            )
            val pi = PendingIntent.getBroadcast(
                this, 0, Intent("com.example.fluidnotif.NOOP").setPackage(packageName),
                PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val builder = Notification.Builder(this, "test_quiet")
                .setSmallIcon(R.drawable.ic_check)
                .setContentTitle(f.title)
                .setContentText(f.text)
            if (f.canReply) {
                val ri = RemoteInput.Builder("reply").setLabel("Reply").build()
                builder.addAction(
                    Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_check), "Reply", pi)
                        .addRemoteInput(ri)
                        .setSemanticAction(Notification.Action.SEMANTIC_ACTION_REPLY).build()
                )
            }
            builder.addAction(
                Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_check), "Mark as read", pi)
                    .setSemanticAction(Notification.Action.SEMANTIC_ACTION_MARK_AS_READ).build()
            )
            nm.notify(notifId++, builder.build())
        }, total)
    }

    private fun sendRealCall(callStyle: Boolean) {
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            return
        }
        val total = delayMs()
        Toast.makeText(this, "Test call in ${total / 1000} s. Go to the home screen", Toast.LENGTH_SHORT).show()
        val name = caller()
        h.postDelayed({
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel("test_call", "Test calls", NotificationManager.IMPORTANCE_HIGH)
            )
            val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            val answer = PendingIntent.getBroadcast(
                this, 21, Intent(CallTestReceiver.ANSWER).setPackage(packageName), flags
            )
            val decline = PendingIntent.getBroadcast(
                this, 22, Intent(CallTestReceiver.DECLINE).setPackage(packageName), flags
            )
            val open = PendingIntent.getActivity(
                this, 23, Intent(this, TestActivity::class.java), flags
            )
            fun build(useStyle: Boolean): Notification {
                val b = Notification.Builder(this, "test_call")
                    .setSmallIcon(R.drawable.ic_call)
                    .setCategory(Notification.CATEGORY_CALL)
                    .setContentTitle(name)
                    .setContentText("Incoming voice call")
                    .setContentIntent(open)
                    .setFullScreenIntent(open, true)
                    .setOngoing(true)
                if (useStyle) {
                    b.setStyle(
                        Notification.CallStyle.forIncomingCall(
                            Person.Builder().setName(name).setImportant(true).build(), decline, answer
                        )
                    )
                } else {
                    b.addAction(
                        Notification.Action.Builder(
                            Icon.createWithResource(this, R.drawable.ic_call_end), "Decline", decline
                        ).build()
                    )
                    b.addAction(
                        Notification.Action.Builder(
                            Icon.createWithResource(this, R.drawable.ic_call), "Answer", answer
                        ).build()
                    )
                }
                return b.build()
            }
            try {
                nm.notify(CallTestReceiver.NOTIF_ID, build(callStyle))
            } catch (e: Exception) {
                Toast.makeText(this, "CallStyle failed here, sent the two-button version", Toast.LENGTH_LONG).show()
                try { nm.notify(CallTestReceiver.NOTIF_ID, build(false)) } catch (_: Exception) {}
            }
        }, total)
    }
}
