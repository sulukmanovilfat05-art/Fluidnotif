package com.example.fluidnotif

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.animation.OvershootInterpolator
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import kotlin.math.abs

/**
 * The whole notification UI: liquid glass card + action pills, with open/close animations.
 * Used both inside the system overlay window and inside the settings preview.
 *
 * Timeline (matches the reference video):
 *  open : ring around the camera pops in (~100 ms) -> blob drips out and spreads into the card
 *         with a soft spring -> text un-blurs -> buttons slide in.
 *  close: text fades -> card flattens into a pill -> pill is sucked back into the camera ->
 *         the ring lingers for a moment and fades.
 */
class NotifPanel(
    private val ctx: Context,
    private val d: NotifData,
    private val st: Style,
    private val geo: Geo,
    private val previewing: Boolean = false
) : LinearLayout(ctx) {

    /** Called when the screen rotates while the panel is showing (the controller then drops it). */
    var onRotate: (() -> Unit)? = null

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        onRotate?.invoke()
    }


    val card = GlassCardView(ctx, d, st, geo)
    private val row = LinearLayout(ctx)
    private val handler = Handler(Looper.getMainLooper())
    private var autoClose: Runnable? = null
    private var closing = false
    private var spring: SpringAnimation? = null
    private val anims = mutableListOf<ValueAnimator>()
    private val fg = if (st.dark) 0xFFF4F4F8.toInt() else 0xFF121216.toInt()
    private val hasButtons = if (d.isCall) (d.onAnswer != null || d.onDecline != null)
        else (st.buttons && (st.btnReply || st.btnRead))

    var onClosed: (() -> Unit)? = null
    var onNeedFocus: ((EditText) -> Unit)? = null

    init {
        orientation = VERTICAL
        addView(card, LayoutParams(MATCH, WRAP))

        row.orientation = HORIZONTAL
        row.gravity = Gravity.CENTER_HORIZONTAL
        if (hasButtons) {
            addView(row, LayoutParams(MATCH, WRAP).apply { topMargin = -dpI(6f) })
            buildButtons()
            row.alpha = 0f
            row.translationY = -dpF(18f)
            row.scaleX = 0.9f
            row.scaleY = 0.9f
        }

        var downY = 0f
        card.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    // Only the card itself is touchable, not the empty strip around the camera.
                    if (e.y < geo.top - dpF(4f)) false else { downY = e.rawY; true }
                }
                MotionEvent.ACTION_UP -> {
                    val dy = e.rawY - downY
                    if (dy < -dpF(28f)) {
                        close()
                    } else if (abs(dy) < dpF(8f)) {
                        d.onOpen()
                        close()
                    }
                    true
                }
                else -> true
            }
        }
    }

    private fun tween(from: Float, to: Float, ms: Long, delay: Long = 0, onEnd: (() -> Unit)? = null,
                      set: (Float) -> Unit) {
        val a = ValueAnimator.ofFloat(from, to).apply {
            duration = ms
            startDelay = delay
            addUpdateListener { set(it.animatedValue as Float) }
            if (onEnd != null) addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) { onEnd() }
            })
        }
        anims.add(a)
        a.start()
    }

    fun open(haptic: Boolean = st.haptic) {
        closing = false
        // 1) ring pops in
        tween(card.ringAlpha, 1f, 110) { card.ringAlpha = it }
        if (haptic) card.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
        // 2) card drips out of it
        handler.postDelayed({
            if (closing) return@postDelayed
            spring = SpringAnimation(card, GlassCardView.PROGRESS, 1f).apply {
                setMinimumVisibleChange(0.002f)
                spring.stiffness = st.openStiffness
                spring.dampingRatio = st.openDamping
                start()
            }
        }, 90)
        // 3) buttons
        if (hasButtons) {
            row.animate()
                .alpha(1f).translationY(0f).scaleX(1f).scaleY(1f)
                .setStartDelay(st.btnDelay + 90).setDuration(320)
                .setInterpolator(OvershootInterpolator(1.4f))
                .start()
        }
        scheduleAutoClose(if (d.isCall && !previewing) st.callStayMs else st.stayMs + 90)
    }

    fun close() {
        if (closing) return
        closing = true
        cancelAuto()
        handler.removeCallbacksAndMessages(null)
        spring?.cancel()
        if (hasButtons) {
            row.animate().alpha(0f).translationY(-dpF(10f)).setStartDelay(0).setDuration(140).start()
        }
        // text fades first...
        tween(card.contentFade, 0f, 120) { card.contentFade = it }
        // ...then the card collapses back into the camera
        handler.postDelayed({
            spring = SpringAnimation(card, GlassCardView.PROGRESS, 0f).apply {
                setMinimumVisibleChange(0.002f)
                spring.stiffness = st.closeStiffness
                spring.dampingRatio = SpringForce.DAMPING_RATIO_NO_BOUNCY
                addEndListener { _, canceled, _, _ ->
                    if (!canceled) {
                        // the ring lingers for a beat, then fades
                        tween(card.ringAlpha, 0f, 260, delay = 140, onEnd = { onClosed?.invoke() }) {
                            card.ringAlpha = it
                        }
                    }
                }
                start()
            }
        }, 70)
    }

    /** Another notification is waiting: leave the current one up for a short moment only. */
    fun hurry() {
        if (!closing && !d.isCall) scheduleAutoClose(1500)
    }

    fun release() {
        cancelAuto()
        handler.removeCallbacksAndMessages(null)
        spring?.cancel()
        anims.forEach { it.removeAllListeners(); it.cancel() }
        anims.clear()
        row.animate().cancel()
    }

    private fun scheduleAutoClose(ms: Long) {
        cancelAuto()
        autoClose = Runnable { close() }.also { handler.postDelayed(it, ms) }
    }

    private fun cancelAuto() {
        autoClose?.let { handler.removeCallbacks(it) }
        autoClose = null
    }

    private fun buildButtons() {
        row.removeAllViews()
        if (d.isCall) {
            d.onDecline?.let { act ->
                row.addView(callPill(d.declineLabel, st.callDecline, R.drawable.ic_call_end) {
                    act(); close()
                }, LayoutParams(0, WRAP, 1f))
            }
            d.onAnswer?.let { act ->
                row.addView(callPill(d.answerLabel, st.callAnswer, R.drawable.ic_call) {
                    act(); close()
                }, LayoutParams(0, WRAP, 1f).apply { if (row.childCount > 0) marginStart = dpI(10f) })
            }
            return
        }
        if (st.btnReply) {
            row.addView(pill("Reply", d.icon(), true) {
                if (d.canReply) showReply() else { d.onOpen(); close() }
            })
        }
        if (st.btnRead) {
            val check = ctx.getDrawable(R.drawable.ic_check)?.mutate()?.also { it.setTint(fg) }
            row.addView(pill("Mark as read", check, false) {
                d.onRead()
                close()
            }, LayoutParams(WRAP, WRAP).apply { marginStart = if (st.btnReply) dpI(8f) else 0 })
        }
    }

    private fun showReply() {
        cancelAuto()
        row.removeAllViews()
        val input = EditText(ctx).apply {
            hint = "Reply…"
            textSize = 15f
            setSingleLine()
            setTextColor(fg)
            setHintTextColor(0xFF8A8A92.toInt())
            setPadding(dpI(20f), 0, dpI(20f), 0)
            background = glassBg()
        }
        row.addView(input, LayoutParams(0, dpI(48f), 1f))
        row.addView(pill("Send", null, false) {
            val text = input.text.toString().trim()
            if (text.isNotEmpty()) d.onReply(text)
            close()
        }, LayoutParams(WRAP, WRAP).apply { marginStart = dpI(8f) })
        row.alpha = 1f
        row.translationY = 0f
        row.scaleX = 1f
        row.scaleY = 1f
        onNeedFocus?.invoke(input)
    }

    private fun glassBg() = GradientDrawable().apply {
        cornerRadius = dpF(24f)
        setColor(if (st.dark) 0xE62A2A30.toInt() else 0xF2FFFFFF.toInt())
        setStroke(dpI(1f), if (st.dark) 0x22FFFFFF else 0x66FFFFFF)
    }

    private fun callPill(label: String, color: Int, iconRes: Int, onClick: () -> Unit): TextView {
        val lum = 0.299f * ((color shr 16) and 0xFF) + 0.587f * ((color shr 8) and 0xFF) + 0.114f * (color and 0xFF)
        val fgc = if (lum > 175f) 0xFF15151B.toInt() else 0xFFFFFFFF.toInt()
        val h = dpI(st.callBtnDp)
        return TextView(ctx).apply {
            text = label
            textSize = 16f * st.textScale
            setTextColor(fgc)
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            minHeight = h
            compoundDrawablePadding = dpI(8f)
            setPadding(dpI(14f), 0, dpI(16f), 0)
            if (st.callIcons) {
                ctx.getDrawable(iconRes)?.mutate()?.let {
                    it.setTint(fgc)
                    it.setBounds(0, 0, dpI(22f), dpI(22f))
                    setCompoundDrawablesRelative(it, null, null, null)
                }
            }
            val bg = GradientDrawable().apply { cornerRadius = minOf(dpF(26f), h / 2f); setColor(color) }
            background = RippleDrawable(ColorStateList.valueOf(0x33000000), bg, null)
            setOnClickListener { onClick() }
        }
    }

    private fun pill(label: String, icon: Drawable?, roundIcon: Boolean, onClick: () -> Unit): TextView {
        return TextView(ctx).apply {
            text = label
            textSize = 15f * st.textScale
            setTextColor(fg)
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
            minHeight = dpI(48f)
            setPadding(dpI(if (icon != null) 12f else 22f), 0, dpI(22f), 0)
            compoundDrawablePadding = dpI(8f)
            icon?.let {
                it.setBounds(0, 0, dpI(if (roundIcon) 28f else 24f), dpI(if (roundIcon) 28f else 24f))
                setCompoundDrawablesRelative(it, null, null, null)
            }
            background = RippleDrawable(ColorStateList.valueOf(0x22000000), glassBg(), null)
            setOnClickListener { onClick() }
        }
    }
}
