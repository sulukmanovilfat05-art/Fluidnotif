package com.example.fluidnotif

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Small in-memory journal of what the notification service saw and decided (shown in the Test lab). */
object NotifLog {
    private val lines = ArrayDeque<String>()
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    @Synchronized
    fun add(line: String) {
        lines.addFirst("${fmt.format(Date())}  $line")
        while (lines.size > 25) lines.removeLast()
    }

    @Synchronized
    fun dump(): String = if (lines.isEmpty()) "Nothing yet. Notifications from other apps will show up here." else lines.joinToString("\n\n")

    @Synchronized
    fun clear() = lines.clear()
}
