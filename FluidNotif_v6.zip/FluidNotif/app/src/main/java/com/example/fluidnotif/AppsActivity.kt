package com.example.fluidnotif

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Switch
import android.widget.TextView

/**
 * Pick which apps may pop up. Every installed app is ON by default;
 * switch off the ones you don't want to see.
 */
class AppsActivity : BaseActivity() {

    private class Row(val pkg: String, val label: String)

    private lateinit var sp: SharedPreferences
    private val blocked = mutableSetOf<String>()
    private var all = listOf<Row>()
    private var shown = listOf<Row>()
    private val icons = HashMap<String, Drawable?>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sp = getSharedPreferences("fluid", Context.MODE_PRIVATE)
        blocked.addAll(sp.getStringSet("blocked", emptySet()) ?: emptySet())

        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        all = pm.queryIntentActivities(launcher, 0)
            .map { Row(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
        shown = all

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(topBar("Apps"))
        root.addView(label("Notifications from every app pop up by default. Switch off the ones you don't want.",
            13.5f, th.sub).apply { setPadding(dpI(22f), 0, dpI(22f), dpI(10f)) })

        val search = EditText(this).apply {
            hint = "Search apps"
            textSize = 15f
            setSingleLine()
            setTextColor(th.text)
            setHintTextColor(th.sub)
            setPadding(dpI(18f), 0, dpI(18f), 0)
            background = th.round(th.card, 18f)
        }
        root.addView(search, LinearLayout.LayoutParams(MATCH, dpI(48f)).apply {
            setMargins(dpI(16f), 0, dpI(16f), dpI(8f))
        })

        val listAdapter = object : BaseAdapter() {
            override fun getCount() = shown.size
            override fun getItem(i: Int) = shown[i]
            override fun getItemId(i: Int) = i.toLong()
            override fun getView(i: Int, convert: View?, parent: ViewGroup): View {
                val r = shown[i]
                val row = (convert as? LinearLayout) ?: LinearLayout(this@AppsActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dpI(16f), dpI(8f), dpI(14f), dpI(8f))
                    addView(ImageView(context), LinearLayout.LayoutParams(dpI(40f), dpI(40f)))
                    addView(TextView(context).apply {
                        textSize = 15.5f
                        setTextColor(th.text)
                        maxLines = 1
                    }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dpI(14f); marginEnd = dpI(8f) })
                    addView(Switch(context))
                }
                (row.getChildAt(0) as ImageView).setImageDrawable(icons.getOrPut(r.pkg) {
                    try { packageManager.getApplicationIcon(r.pkg) } catch (e: Exception) { null }
                })
                (row.getChildAt(1) as TextView).text = r.label
                val sw = row.getChildAt(2) as Switch
                sw.setOnCheckedChangeListener(null)
                sw.isChecked = r.pkg !in blocked
                val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
                sw.thumbTintList = android.content.res.ColorStateList(states, intArrayOf(0xFFFFFFFF.toInt(), 0xFFFFFFFF.toInt()))
                sw.trackTintList = android.content.res.ColorStateList(states, intArrayOf(th.accent, th.alpha(th.sub, 0x66)))
                sw.setOnCheckedChangeListener { _, on ->
                    if (on) blocked.remove(r.pkg) else blocked.add(r.pkg)
                    sp.edit().putStringSet("blocked", HashSet(blocked)).apply()
                }
                row.setOnClickListener { sw.toggle() }
                return row
            }
        }

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val q = s?.toString().orEmpty().trim().lowercase()
                shown = if (q.isEmpty()) all else all.filter { it.label.lowercase().contains(q) }
                listAdapter.notifyDataSetChanged()
            }
        })

        val list = ListView(this).apply {
            adapter = listAdapter
            divider = null
            setSelector(android.R.color.transparent)
            clipToPadding = false
            setPadding(0, 0, 0, dpI(24f))
        }
        root.addView(list, LinearLayout.LayoutParams(MATCH, 0, 1f))

        setPage(root)
    }
}
