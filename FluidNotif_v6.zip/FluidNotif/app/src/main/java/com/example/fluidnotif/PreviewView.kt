package com.example.fluidnotif

import android.content.Context
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * A tiny "phone" (lock screen with a camera dot) that plays the real notification animation
 * in a loop, using the current settings. Used on the home screen and in settings.
 */
class PreviewView(context: Context, private val cycle: Boolean) : FrameLayout(context) {

    private val h = Handler(Looper.getMainLooper())
    private val stage = FrameLayout(context)
    private val sp = context.getSharedPreferences("fluid", Context.MODE_PRIVATE)
    private var panel: NotifPanel? = null
    private var index = 0
    private var callMode = false
    private val playRun = Runnable { play() }

    init {
        background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xFFFFA06A.toInt(), 0xFFF58A5C.toInt(), 0xFFE8A3B8.toInt())
        )
        clipToOutline = true
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, view.dpF(28f))
            }
        }
        setOnClickListener { schedule(0) }

        // fake lock screen: clock + date + camera
        val clock = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            addView(TextView(context).apply {
                text = "9:41"
                textSize = 54f
                setTextColor(0xF2FFFFFF.toInt())
                typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
                includeFontPadding = false
            })
            addView(TextView(context).apply {
                text = "Sunday, November 8"
                textSize = 13f
                setTextColor(0xCCFFFFFF.toInt())
            })
        }
        addView(clock, LayoutParams(MATCH, WRAP, Gravity.CENTER_HORIZONTAL).apply { topMargin = dpI(112f) })

        val dot = View(context).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFF000000.toInt()) }
        }
        addView(dot, LayoutParams(dpI(11f), dpI(11f), Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dpI(14f)
        })
        addView(stage, LayoutParams(MATCH, MATCH))
    }

    private fun schedule(ms: Long) {
        h.removeCallbacks(playRun)
        h.postDelayed(playRun, ms)
    }

    /** Show a ringing call instead of a message in the preview. */
    fun setCallMode(on: Boolean) {
        if (callMode != on) { callMode = on; replay(150) }
    }

    /** Call after a setting changed to replay with the new look. */
    fun replay(ms: Long = 250) = schedule(ms)

    private fun releasePanel() {
        panel?.let {
            it.release()
            stage.removeView(it)
        }
        panel = null
    }

    private fun play() {
        releasePanel()
        val w = stage.width
        if (w == 0) { schedule(100); return }
        val st = Style(sp)
        val m = dpI(st.marginDp)
        val camR = dpF(5.5f)
        val cy = dpF(14f) + camR
        val r = camR + dpF(st.ringPadDp)
        val top = (cy + r + dpF(st.topGapDp)).coerceAtLeast(cy + 1f)
        val geo = Geo((w - 2 * m) / 2f, cy, r, top)

        val fake = when {
            callMode -> Fakes.scenarios.first { it.isCall }
            cycle -> Fakes.scenarios[index++ % 3]
            else -> Fakes.scenarios[0]
        }
        val p = NotifPanel(context, fake.toData(context, toasts = false), st, geo, previewing = true)
        p.onClosed = {
            if (panel === p) {
                stage.removeView(p)
                panel = null
                schedule(if (cycle) 700 else 900)
            }
        }
        stage.addView(p, LayoutParams(MATCH, WRAP).apply { setMargins(m, 0, m, 0) })
        panel = p
        p.open(haptic = false)
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == View.VISIBLE) schedule(400) else {
            h.removeCallbacksAndMessages(null)
            releasePanel()
        }
    }

    override fun onDetachedFromWindow() {
        h.removeCallbacksAndMessages(null)
        releasePanel()
        super.onDetachedFromWindow()
    }
}
