package com.example.fluidnotif

import android.content.SharedPreferences

enum class T { SWITCH, SLIDER, CHOICE }

data class Opt(
    val key: String,
    val title: String,
    val type: T,
    val def: Int,
    val min: Int = 0,
    val max: Int = 1,
    val unit: String = "",
    val choices: List<String> = emptyList(),
    val section: String = ""
)

/** Single source of truth for every setting: the settings screen is generated from this list. */
object Opts {
    val EDGE_COLORS = listOf(
        "Purple" to 0xFFA98BFF.toInt(),
        "Cyan" to 0xFF4FD8FF.toInt(),
        "Pink" to 0xFFFF7AC8.toInt(),
        "Orange" to 0xFFFFB066.toInt(),
        "Green" to 0xFF6BE3A0.toInt(),
        "White" to 0xFFFFFFFF.toInt()
    )
    private val colorNames = EDGE_COLORS.map { it.first }

    val ANSWER_COLORS = listOf(
        "Green" to 0xFF28C760.toInt(),
        "Blue" to 0xFF2F80ED.toInt(),
        "Teal" to 0xFF14B8A6.toInt(),
        "White" to 0xFFFFFFFF.toInt()
    )
    val DECLINE_COLORS = listOf(
        "Red" to 0xFFE5483D.toInt(),
        "Orange" to 0xFFF2994A.toInt(),
        "Pink" to 0xFFFF5C9A.toInt(),
        "Dark" to 0xFF2B2B33.toInt()
    )

    /** Colour palette behind a CHOICE option (to show a coloured dot), if it has one. */
    fun palette(key: String): List<Pair<String, Int>>? = when (key) {
        "edge_c1", "edge_c2" -> EDGE_COLORS
        "call_ans" -> ANSWER_COLORS
        "call_dec" -> DECLINE_COLORS
        else -> null
    }

    private fun sl(sec: String, key: String, title: String, def: Int, min: Int, max: Int, unit: String = "") =
        Opt(key, title, T.SLIDER, def, min, max, unit, section = sec)

    private fun sw(sec: String, key: String, title: String, def: Int) =
        Opt(key, title, T.SWITCH, def, section = sec)

    private fun ch(sec: String, key: String, title: String, def: Int, choices: List<String>) =
        Opt(key, title, T.CHOICE, def, choices = choices, section = sec)

    val list = listOf(
        // Animation
        sl("Animation", "open_stiffness", "Open speed (spring stiffness)", 340, 100, 1000),
        sl("Animation", "open_damping", "Open bounce (lower = bouncier)", 76, 20, 100, "%"),
        sl("Animation", "close_stiffness", "Close speed", 380, 100, 1000),
        sl("Animation", "stay_s", "Stay on screen", 4, 1, 20, " s"),
        sl("Animation", "btn_delay", "Buttons appear after", 140, 0, 600, " ms"),
        sl("Animation", "text_blur", "Text blur while appearing", 18, 0, 40, " dp"),
        sw("Animation", "haptic", "Haptic tick when it appears", 1),
        // Look
        sw("Look", "dark", "Dark glass", 0),
        sl("Look", "glass_alpha", "Glass opacity", 90, 30, 100, "%"),
        sl("Look", "corner", "Corner radius", 28, 8, 44, " dp"),
        sl("Look", "margin", "Side margin", 8, 0, 32, " dp"),
        sl("Look", "top_gap", "Gap below camera", 10, -4, 40, " dp"),
        sw("Look", "neck", "Liquid neck from the camera", 1),
        sl("Look", "ring_pad", "Ring around camera (tenths of dp)", 40, 0, 120),
        sl("Look", "icon_size", "Icon size", 42, 24, 60, " dp"),
        sl("Look", "text_scale", "Text size", 100, 80, 140, "%"),
        sw("Look", "edge_on", "Glowing coloured edge", 0),
        sl("Look", "edge_w", "Edge thickness (tenths of dp)", 15, 5, 50),
        sl("Look", "glow", "Edge glow", 18, 0, 100, "%"),
        ch("Look", "edge_c1", "Edge colour 1", 0, colorNames),
        ch("Look", "edge_c2", "Edge colour 2", 1, colorNames),
        // Content
        sw("Content", "hide", "Hide message text (\"Message hidden\")", 0),
        sw("Content", "buttons", "Show action buttons", 1),
        sw("Content", "btn_reply", "Reply button", 1),
        sw("Content", "btn_read", "Mark as read button", 1),
        sw("Content", "avatar", "Show contact photo when available", 1),
        // Calls
        sw("Calls", "call_on", "Show incoming calls at the camera", 1),
        sl("Calls", "call_stay", "Keep ringing panel on screen", 45, 10, 120, " s"),
        sl("Calls", "call_btn_h", "Button height", 52, 40, 72, " dp"),
        sw("Calls", "call_icons", "Phone icons on the buttons", 1),
        ch("Calls", "call_ans", "Answer button colour", 0, ANSWER_COLORS.map { it.first }),
        ch("Calls", "call_dec", "Decline button colour", 0, DECLINE_COLORS.map { it.first }),
        // Landscape
        sw("Landscape", "land_on", "Show when the phone is sideways (video, games)", 1),
        sl("Landscape", "land_w", "Card width in landscape", 520, 300, 800, " dp"),
        // Behaviour
        sw("Behaviour", "skip_ongoing", "Ignore ongoing (music, calls, timers)", 1),
        sw("Behaviour", "silent", "Also show silent notifications", 0),
        sw("Behaviour", "dnd", "Respect Do Not Disturb", 1),
        sw("Behaviour", "blur", "Real background blur (experimental)", 0),
        sl("Behaviour", "blur_r", "Blur strength", 28, 5, 60, " dp")
    )

    private val defaults = list.associate { it.key to it.def }

    fun i(sp: SharedPreferences, key: String): Int = sp.getInt(key, defaults.getValue(key))
    fun b(sp: SharedPreferences, key: String): Boolean = i(sp, key) != 0
}

/** Snapshot of all settings, read once per notification. */
class Style(private val sp: SharedPreferences) {
    private fun i(k: String) = Opts.i(sp, k)
    private fun b(k: String) = Opts.b(sp, k)

    val openStiffness = i("open_stiffness").toFloat()
    val openDamping = i("open_damping") / 100f
    val closeStiffness = i("close_stiffness").toFloat()
    val stayMs = i("stay_s") * 1000L
    val btnDelay = i("btn_delay").toLong()
    val textBlurDp = i("text_blur").toFloat()
    val haptic = b("haptic")

    val dark = b("dark")
    val glassAlpha = i("glass_alpha") * 255 / 100
    val cornerDp = i("corner").toFloat()
    val marginDp = i("margin").toFloat()
    val topGapDp = i("top_gap").toFloat()
    val neck = b("neck")
    val ringPadDp = i("ring_pad") / 10f
    val iconDp = i("icon_size").toFloat()
    val textScale = i("text_scale") / 100f
    val edgeOn = b("edge_on")
    val edgeWDp = i("edge_w") / 10f
    val glowAlpha = i("glow") * 255 / 100
    val c1 = Opts.EDGE_COLORS[i("edge_c1").coerceIn(0, Opts.EDGE_COLORS.size - 1)].second
    val c2 = Opts.EDGE_COLORS[i("edge_c2").coerceIn(0, Opts.EDGE_COLORS.size - 1)].second

    val hide = b("hide")
    val buttons = b("buttons")
    val btnReply = b("btn_reply")
    val btnRead = b("btn_read")
    val avatar = b("avatar")

    val callOn = b("call_on")
    val callStayMs = i("call_stay") * 1000L
    val callBtnDp = i("call_btn_h").toFloat()
    val callIcons = b("call_icons")
    val callAnswer = Opts.ANSWER_COLORS[i("call_ans").coerceIn(0, Opts.ANSWER_COLORS.size - 1)].second
    val callDecline = Opts.DECLINE_COLORS[i("call_dec").coerceIn(0, Opts.DECLINE_COLORS.size - 1)].second

    val landOn = b("land_on")
    val landW = i("land_w").toFloat()

    val skipOngoing = b("skip_ongoing")
    val silent = b("silent")
    val dnd = b("dnd")
    val blur = b("blur")
    val blurDp = i("blur_r").toFloat()
    val blocked: Set<String> = sp.getStringSet("blocked", emptySet()) ?: emptySet()
}
