package com.example.fluidnotif

import android.app.Activity
import android.content.Context
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

/** Colours for the app's own screens (follows the system light / dark mode). */
class Theme(private val ctx: Context) {
    val night = (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
        Configuration.UI_MODE_NIGHT_YES

    private fun pick(dark: Long, light: Long): Int = (if (night) dark else light).toInt()

    val accent = 0xFF5B6CFF.toInt()
    val ok = 0xFF2BB673.toInt()
    val bad = 0xFFE5483D.toInt()
    val bgTop = pick(0xFF1A1A24, 0xFFFFF1E5)
    val bgBottom = pick(0xFF0C0C11, 0xFFE6F2FB)
    val card = pick(0xFF22222C, 0xFFFFFFFF)
    val chip = pick(0xFF2C2C38, 0xFFF0F1F7)
    val text = pick(0xFFF4F4F9, 0xFF15151B)
    val sub = pick(0xFF9D9DAB, 0xFF6B6B78)
    val line = pick(0x22FFFFFF, 0x12000000)

    fun gradientBg() = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(bgTop, bgBottom))

    fun round(color: Int, radiusDp: Float) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = ctx.dpF(radiusDp)
    }

    fun ripple(content: Drawable): Drawable =
        RippleDrawable(ColorStateList.valueOf(if (night) 0x33FFFFFF else 0x14000000), content, null)

    fun alpha(c: Int, a: Int): Int = (c and 0x00FFFFFF) or (a shl 24)
}

/** Base for all app screens: edge-to-edge, themed background, and a small kit of builders. */
abstract class BaseActivity : Activity() {
    lateinit var th: Theme

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        th = Theme(this)
        window.setDecorFitsSystemWindows(false)
    }

    fun setPage(root: View) {
        root.background = th.gradientBg()
        root.setOnApplyWindowInsetsListener { v, ins ->
            val b = ins.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.ime())
            v.setPadding(0, b.top, 0, b.bottom)
            WindowInsets.CONSUMED
        }
        setContentView(root)
    }

    fun scroller(content: View): ScrollView = ScrollView(this).apply {
        addView(content)
        isVerticalScrollBarEnabled = false
        overScrollMode = View.OVER_SCROLL_NEVER
    }

    fun label(s: String, sp: Float, color: Int = th.text, bold: Boolean = false): TextView = TextView(this).apply {
        text = s
        textSize = sp
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    fun space(dp: Float): View = View(this).apply { minimumHeight = dpI(dp) }

    fun sectionHeader(s: String): TextView = label(s.uppercase(), 12f, th.accent, true).apply {
        letterSpacing = 0.08f
        setPadding(dpI(6f), dpI(22f), 0, dpI(8f))
    }

    /** Rounded white/dark surface that groups rows. */
    fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = th.round(th.card, 22f)
        setPadding(dpI(4f), dpI(4f), dpI(4f), dpI(4f))
        elevation = dpF(if (th.night) 0f else 1.5f)
    }

    fun divider(): View = View(this).apply {
        setBackgroundColor(th.line)
        layoutParams = LinearLayout.LayoutParams(MATCH, 1).apply {
            marginStart = dpI(16f)
            marginEnd = dpI(16f)
        }
    }

    fun topBar(title: String, back: Boolean = true): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dpI(8f), dpI(6f), dpI(20f), dpI(6f))
        if (back) {
            addView(TextView(this@BaseActivity).apply {
                text = "‹"
                textSize = 34f
                gravity = Gravity.CENTER
                setTextColor(th.text)
                background = th.ripple(th.round(0, 24f))
                setOnClickListener { finish() }
            }, LinearLayout.LayoutParams(dpI(48f), dpI(48f)))
        } else {
            addView(space(1f), LinearLayout.LayoutParams(dpI(12f), 1))
        }
        addView(label(title, 20f, th.text, true))
    }

    /** Rounded colour square with an emoji inside. */
    fun badge(emoji: String, color: Int, sizeDp: Float = 40f): View = TextView(this).apply {
        text = emoji
        textSize = 18f
        gravity = Gravity.CENTER
        background = th.round(th.alpha(color, if (th.night) 0x55 else 0x30), 13f)
        layoutParams = LinearLayout.LayoutParams(dpI(sizeDp), dpI(sizeDp))
    }

    /** Big tappable row: badge + title + subtitle (+ optional trailing view). */
    fun tileRow(emoji: String, color: Int, title: String, sub: String?, trailing: View? = null,
                onClick: () -> Unit): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dpI(14f), dpI(12f), dpI(14f), dpI(12f))
        background = th.ripple(th.round(0, 18f))
        addView(badge(emoji, color))
        val col = LinearLayout(this@BaseActivity).apply { orientation = LinearLayout.VERTICAL }
        col.addView(label(title, 16f, th.text, true))
        if (sub != null) col.addView(label(sub, 13f, th.sub).apply { setPadding(0, dpI(2f), 0, 0) })
        addView(col, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dpI(14f) })
        if (trailing != null) addView(trailing)
        setOnClickListener { onClick() }
    }

    fun chipText(s: String, color: Int): TextView = label(s, 12.5f, color, true).apply {
        setPadding(dpI(10f), dpI(5f), dpI(10f), dpI(5f))
        background = th.round(th.alpha(color, 0x26), 12f)
    }

    fun button(text: String, filled: Boolean, onClick: () -> Unit): TextView = TextView(this).apply {
        this.text = text
        textSize = 16f
        gravity = Gravity.CENTER
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(if (filled) Color.WHITE else th.text)
        background = th.ripple(th.round(if (filled) th.accent else th.chip, 18f))
        minHeight = dpI(52f)
        setOnClickListener { onClick() }
    }

    private fun tintSwitch(sw: Switch) {
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(states, intArrayOf(Color.WHITE, Color.WHITE))
        sw.trackTintList = ColorStateList(states, intArrayOf(th.accent, th.alpha(th.sub, 0x66)))
    }

    fun switchRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dpI(16f), dpI(10f), dpI(12f), dpI(10f))
            minimumHeight = dpI(52f)
        }
        row.addView(label(title, 15.5f), LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dpI(10f) })
        val sw = Switch(this).apply {
            isChecked = checked
            tintSwitch(this)
            setOnCheckedChangeListener { _, v -> onChange(v) }
        }
        row.addView(sw)
        row.setOnClickListener { sw.toggle() }
        return row
    }

    fun sliderRow(o: Opt, cur: Int, onChange: (Int) -> Unit): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpI(16f), dpI(12f), dpI(16f), dpI(6f))
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val value = label("$cur${o.unit}", 14.5f, th.accent, true)
        head.addView(label(o.title, 15.5f), LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dpI(8f) })
        head.addView(value)
        box.addView(head)
        val bar = SeekBar(this).apply {
            max = o.max - o.min
            progress = cur - o.min
            progressTintList = ColorStateList.valueOf(th.accent)
            thumbTintList = ColorStateList.valueOf(th.accent)
            progressBackgroundTintList = ColorStateList.valueOf(th.alpha(th.sub, 0x44))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    val v = p + o.min
                    value.text = "$v${o.unit}"
                    if (fromUser) onChange(v)
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }
        box.addView(bar, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dpI(2f) })
        return box
    }

    fun choiceRow(title: String, current: String, dotColor: Int?, onClick: () -> Unit): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dpI(16f), dpI(10f), dpI(16f), dpI(10f))
            minimumHeight = dpI(52f)
            background = th.ripple(th.round(0, 18f))
            setOnClickListener { onClick() }
        }
        row.addView(label(title, 15.5f), LinearLayout.LayoutParams(0, WRAP, 1f))
        if (dotColor != null) {
            row.addView(View(this).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(dotColor) }
            }, LinearLayout.LayoutParams(dpI(14f), dpI(14f)).apply { marginEnd = dpI(8f) })
        }
        row.addView(label("$current  ›", 14.5f, th.sub))
        return row
    }
}
