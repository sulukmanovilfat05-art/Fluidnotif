package com.example.fluidnotif

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * One switch for ALL apps: turns the system's heads-up pop-ups off / on
 * (Settings.Global "heads_up_notifications_enabled"). The notifications themselves stay in the shade.
 * Writing that setting needs WRITE_SECURE_SETTINGS, which can only be granted once over ADB.
 */
class PopupsActivity : BaseActivity() {

    private val key = "heads_up_notifications_enabled"
    private lateinit var status: TextView
    private lateinit var chip: TextView
    private lateinit var actions: LinearLayout
    private lateinit var setup: LinearLayout

    private val adbCommand get() = "adb shell pm grant $packageName android.permission.WRITE_SECURE_SETTINGS"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(topBar("System pop-ups"))

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpI(16f), 0, dpI(16f), dpI(36f))
        }

        col.addView(label(
            "Turns off the little banners that every app (Telegram, WhatsApp, calls...) drops from the top, " +
                "so only the Fluid one shows. The notifications are NOT deleted: they still arrive in the " +
                "notification shade.", 14f, th.sub
        ).apply { setPadding(dpI(6f), dpI(4f), dpI(6f), dpI(8f)) })

        col.addView(sectionHeader("Status"))
        val sCard = card()
        chip = chipText("", th.sub)
        status = label("", 13.5f, th.sub).apply { setPadding(dpI(16f), dpI(4f), dpI(16f), dpI(12f)) }
        sCard.addView(tileRow("🔕", 0xFFF2994A.toInt(), "Pop-ups for all apps", null, chip) { refresh() })
        sCard.addView(status)
        col.addView(sCard)

        // Buttons (shown once the permission is granted)
        actions = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        actions.addView(space(12f))
        actions.addView(button("Turn OFF all pop-ups", true) { setPopups(false) },
            LinearLayout.LayoutParams(MATCH, WRAP))
        actions.addView(space(10f))
        actions.addView(button("Turn ON all pop-ups again", false) { setPopups(true) },
            LinearLayout.LayoutParams(MATCH, WRAP))
        col.addView(actions)

        // One-time setup (shown while the permission is missing)
        setup = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        setup.addView(sectionHeader("One-time setup"))
        val c = card()
        c.addView(label(
            "Android only lets an app change this after you allow it once with a computer " +
                "(or an on-device ADB app such as LADB). Run this single command:", 14f
        ).apply { setPadding(dpI(16f), dpI(12f), dpI(16f), dpI(6f)) })
        c.addView(TextView(this).apply {
            text = adbCommand
            textSize = 12.5f
            typeface = android.graphics.Typeface.MONOSPACE
            setTextColor(th.text)
            setTextIsSelectable(true)
            background = th.round(th.chip, 12f)
            setPadding(dpI(12f), dpI(10f), dpI(12f), dpI(10f))
        }, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(dpI(12f), dpI(4f), dpI(12f), dpI(8f)) })
        c.addView(label(
            "USB debugging (or Wireless debugging) must be on in Developer options. " +
                "After the command, come back here and tap \"Check again\".", 13f, th.sub
        ).apply { setPadding(dpI(16f), 0, dpI(16f), dpI(10f)) })
        setup.addView(c)
        setup.addView(space(10f))
        setup.addView(button("Copy command", true) {
            getSystemService(ClipboardManager::class.java)
                .setPrimaryClip(ClipData.newPlainText("adb", adbCommand))
            Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(MATCH, WRAP))
        setup.addView(space(10f))
        setup.addView(button("Check again", false) { refresh() }, LinearLayout.LayoutParams(MATCH, WRAP))
        col.addView(setup)

        col.addView(sectionHeader("Without a computer"))
        val alt = card()
        alt.addView(tileRow("⚙️", 0xFF5B6CFF.toInt(), "Open notification settings",
            "Turn off \"Pop-up\" per app by hand", null) {
            try {
                startActivity(Intent("android.settings.NOTIFICATION_SETTINGS"))
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
        })
        col.addView(alt)
        col.addView(label(
            "If you ever uninstall this app while pop-ups are off, turn them on here first.\n" +
                "On some One UI versions the system may ignore this switch; the button then shows what happened.",
            12.5f, th.sub
        ).apply { setPadding(dpI(8f), dpI(16f), dpI(8f), 0) })

        root.addView(scroller(col), LinearLayout.LayoutParams(MATCH, 0, 1f))
        setPage(root)
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun granted() =
        checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED

    private fun popupsOn(): Boolean = Settings.Global.getInt(contentResolver, key, 1) != 0

    private fun setPopups(on: Boolean) {
        val ok = try {
            Settings.Global.putInt(contentResolver, key, if (on) 1 else 0)
        } catch (e: Exception) {
            false
        }
        val now = popupsOn()
        Toast.makeText(
            this,
            when {
                !ok -> "Not allowed. Run the setup command first."
                now == on -> if (on) "Pop-ups are ON" else "Pop-ups are OFF"
                else -> "The system ignored the change"
            },
            Toast.LENGTH_LONG
        ).show()
        refresh()
    }

    private fun refresh() {
        val g = granted()
        actions.visibility = if (g) android.view.View.VISIBLE else android.view.View.GONE
        setup.visibility = if (g) android.view.View.GONE else android.view.View.VISIBLE
        val on = popupsOn()
        val color = if (!on) th.ok else th.sub
        chip.text = if (on) "Pop-ups ON" else "✓ Pop-ups OFF"
        chip.setTextColor(color)
        chip.background = th.round(th.alpha(color, 0x26), 12f)
        status.text = when {
            !g -> "Permission not given yet (see one-time setup below)."
            on -> "Every app can show its own pop-up."
            else -> "No app shows its own pop-up. Fluid notifications still appear."
        }
        status.ellipsize = TextUtils.TruncateAt.END
        status.maxLines = 4
    }
}
