package com.example.fluidnotif

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.Toast

class TestActivity : BaseActivity() {

    private val h = Handler(Looper.getMainLooper())
    private lateinit var delay: EditText
    private lateinit var fApp: EditText
    private lateinit var fTitle: EditText
    private lateinit var fText: EditText
    private lateinit var fReply: Switch
    private var notifId = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(topBar("Test lab"))

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpI(16f), 0, dpI(16f), dpI(36f))
        }

        fun field(box: LinearLayout, hint: String, init: String): EditText {
            val e = EditText(this).apply {
                this.hint = hint
                setText(init)
                textSize = 15.5f
                setTextColor(th.text)
                setHintTextColor(th.sub)
                setSingleLine()
                background = th.round(th.chip, 14f)
                setPadding(dpI(16f), 0, dpI(16f), 0)
            }
            box.addView(e, LinearLayout.LayoutParams(MATCH, dpI(48f)).apply {
                setMargins(dpI(12f), dpI(6f), dpI(12f), dpI(6f))
            })
            return e
        }

        col.addView(label(
            "Fake notifications to try your settings. Set a delay, tap a scenario, then go to the home screen " +
                "and watch it flow out of the camera.", 13.5f, th.sub
        ).apply { setPadding(dpI(6f), dpI(4f), dpI(6f), dpI(4f)) })

        col.addView(sectionHeader("Delay before showing (seconds)"))
        val dcard = card()
        delay = field(dcard, "seconds", "3").apply { inputType = InputType.TYPE_CLASS_NUMBER }
        col.addView(dcard)

        col.addView(sectionHeader("Quick scenarios"))
        val scen = card()
        Fakes.scenarios.forEachIndexed { i, f ->
            if (i > 0) scen.addView(divider())
            scen.addView(tileRow(f.app.take(1), f.color, f.app, f.title, null) { fire(f) })
        }
        col.addView(scen)

        col.addView(sectionHeader("Custom"))
        val ccard = card()
        fApp = field(ccard, "App name", "Telegram")
        fTitle = field(ccard, "Title", "Sam")
        fText = field(ccard, "Message", "Are we still on for lunch today?")
        fReply = Switch(this).apply { isChecked = true }
        ccard.addView(switchRow("Can reply", true) { fReply.isChecked = it })
        col.addView(ccard)
        col.addView(space(10f))
        col.addView(button("Show custom fake overlay", true) { fire(custom()) },
            LinearLayout.LayoutParams(MATCH, WRAP))

        col.addView(sectionHeader("More"))
        val more = card()
        more.addView(tileRow("⚡", 0xFFF2994A.toInt(), "Burst",
            "3 notifications in a row (tests the queue)", null) {
            Fakes.scenarios.take(3).forEachIndexed { i, f -> fire(f, extraMs = i * 600L) }
        })
        more.addView(divider())
        more.addView(tileRow("🔔", 0xFF5B6CFF.toInt(), "Send a REAL notification",
            "Goes through the whole pipeline, like Telegram would", null) { sendReal(custom()) })
        more.addView(divider())
        more.addView(tileRow("✕", 0xFFE5483D.toInt(), "Dismiss current overlay", null, null) {
            OverlayController.dismiss()
        })
        col.addView(more)

        setPage(scroller(col))
    }

    private fun custom() = Fake(
        fApp.text.toString().ifBlank { "App" },
        fTitle.text.toString(),
        fText.text.toString(),
        0xFF8E5BFF.toInt(),
        fReply.isChecked
    )

    private fun delayMs(): Long = (delay.text.toString().toLongOrNull() ?: 0L) * 1000L

    private fun fire(f: Fake, extraMs: Long = 0L) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Grant \"Display over other apps\" first", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        val total = delayMs() + extraMs
        if (total >= 1000 && extraMs == 0L) {
            Toast.makeText(this, "Showing in ${total / 1000} s — go to the home screen", Toast.LENGTH_SHORT).show()
        }
        val data = f.toData(this)
        h.postDelayed({ OverlayController.show(applicationContext, data) }, total)
    }

    private fun sendReal(f: Fake) {
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            return
        }
        val total = delayMs()
        Toast.makeText(this, "Real notification in ${total / 1000} s", Toast.LENGTH_SHORT).show()
        h.postDelayed({
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel("test", "Test", NotificationManager.IMPORTANCE_HIGH)
            )
            val pi = PendingIntent.getBroadcast(
                this, 0, Intent("com.example.fluidnotif.NOOP").setPackage(packageName),
                PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val builder = Notification.Builder(this, "test")
                .setSmallIcon(R.drawable.ic_check)
                .setContentTitle(f.title)
                .setContentText(f.text)
            if (f.canReply) {
                val ri = RemoteInput.Builder("reply").setLabel("Reply").build()
                builder.addAction(
                    Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_check), "Reply", pi)
                        .addRemoteInput(ri)
                        .setSemanticAction(Notification.Action.SEMANTIC_ACTION_REPLY).build()
                )
            }
            builder.addAction(
                Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_check), "Mark as read", pi)
                    .setSemanticAction(Notification.Action.SEMANTIC_ACTION_MARK_AS_READ).build()
            )
            nm.notify(notifId++, builder.build())
        }, total)
    }
}
