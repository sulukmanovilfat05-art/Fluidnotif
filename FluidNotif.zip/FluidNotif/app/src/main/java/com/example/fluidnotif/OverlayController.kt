package com.example.fluidnotif

import android.content.Context
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import kotlin.math.max

/**
 * Puts a [NotifPanel] into a system overlay window anchored at the camera.
 * Notifications that arrive while one is on screen are queued and shown one after another.
 */
object OverlayController {

    private var wm: WindowManager? = null
    private var panel: NotifPanel? = null
    private var currentKey: String? = null
    private var waiting = false
    private val queue = ArrayDeque<Pair<Context, NotifData>>()
    private val main = Handler(Looper.getMainLooper())

    fun show(base: Context, d: NotifData) {
        if (!Settings.canDrawOverlays(base)) return
        val pm = base.getSystemService(PowerManager::class.java)
        if (pm != null && !pm.isInteractive) return // screen is off, nobody would see it

        val cur = panel
        if (cur != null && d.key != null && d.key == currentKey) {
            // same conversation got a newer message: replace it right away
            removeNow()
            display(base, d)
            return
        }
        if (cur == null && !waiting) {
            display(base, d)
            return
        }
        queue.removeAll { it.second.key != null && it.second.key == d.key }
        queue.addLast(base to d)
        while (queue.size > 4) queue.removeFirst()
        cur?.hurry()
    }

    private fun display(base: Context, d: NotifData) {
        removeNow()

        val st = Style(base.getSharedPreferences("fluid", Context.MODE_PRIVATE))
        val ctx = ContextThemeWrapper(base, android.R.style.Theme_DeviceDefault_Light_NoActionBar)
        val manager = base.getSystemService(WindowManager::class.java)
        wm = manager

        // Where is the camera?
        val metrics = manager.currentWindowMetrics
        val screenW = metrics.bounds.width()
        val cut = metrics.windowInsets.displayCutout?.boundingRects
            ?.firstOrNull { it.top <= 0 && it.width() < screenW / 2 }
        val cam = if (cut != null) RectF(cut) else RectF(
            screenW / 2f - ctx.dpF(7f), ctx.dpF(13f),
            screenW / 2f + ctx.dpF(7f), ctx.dpF(27f)
        )
        val margin = ctx.dpI(st.marginDp)
        val ringR = max(cam.width(), cam.height()) / 2f + ctx.dpF(st.ringPadDp)
        val cy = cam.centerY()
        val top = (cy + ringR + ctx.dpF(st.topGapDp)).coerceAtLeast(cy + 1f)
        val geo = Geo(cam.centerX() - margin, cy, ringR, top)

        val p = NotifPanel(ctx, d, st, geo)

        val lp = WindowManager.LayoutParams(
            screenW - margin * 2,
            WRAP,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = 0
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            if (st.blur) {
                // Experimental: blurs the whole window rectangle, not only the rounded card.
                flags = flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
                blurBehindRadius = ctx.dpI(st.blurDp)
            }
        }

        p.onClosed = {
            if (panel === p) {
                removeNow()
                waiting = true
                main.postDelayed({
                    waiting = false
                    if (panel == null) {
                        queue.removeFirstOrNull()?.let { display(it.first, it.second) }
                    }
                }, 140)
            }
        }
        p.onNeedFocus = { input ->
            // Make the overlay focusable so the keyboard can appear.
            lp.flags = lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
            lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING
            try { manager.updateViewLayout(p, lp) } catch (_: Exception) {}
            input.requestFocus()
            input.postDelayed({
                ctx.getSystemService(InputMethodManager::class.java)
                    .showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
            }, 150)
        }

        try {
            manager.addView(p, lp)
        } catch (e: Exception) {
            return
        }
        panel = p
        currentKey = d.key
        p.open()
    }

    fun dismiss() {
        queue.clear()
        panel?.close()
    }

    private fun removeNow() {
        panel?.let {
            it.release()
            try { wm?.removeViewImmediate(it) } catch (_: Exception) {}
        }
        panel = null
        currentKey = null
    }
}
