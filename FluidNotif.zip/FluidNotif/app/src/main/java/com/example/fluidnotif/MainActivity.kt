package com.example.fluidnotif

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationManagerCompat

class MainActivity : BaseActivity() {

    private lateinit var accessChip: TextView
    private lateinit var overlayChip: TextView
    private lateinit var accessRow: LinearLayout
    private lateinit var overlayRow: LinearLayout
    private lateinit var summary: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpI(18f), dpI(14f), dpI(18f), dpI(28f))
        }

        col.addView(label("Fluid Notifications", 30f, th.text, true).apply { setPadding(dpI(6f), dpI(10f), 0, 0) })
        col.addView(label("Notifications that flow out of your camera.", 15f, th.sub)
            .apply { setPadding(dpI(6f), dpI(4f), 0, dpI(16f)) })

        // Live preview of the real animation
        col.addView(PreviewView(this, cycle = true), LinearLayout.LayoutParams(MATCH, dpI(236f)))

        // --- Setup ---
        col.addView(sectionHeader("Setup"))
        summary = label("", 13.5f, th.sub).apply { setPadding(dpI(6f), 0, dpI(6f), dpI(10f)) }
        col.addView(summary)

        val setup = card()
        accessChip = chipText("", th.bad)
        overlayChip = chipText("", th.bad)
        accessRow = tileRow("🔔", 0xFF5B6CFF.toInt(), "Notification access",
            "Lets the app see Telegram, WhatsApp, SMS and every other app", accessChip) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        } as LinearLayout
        overlayRow = tileRow("🪟", 0xFF2F80ED.toInt(), "Display over other apps",
            "Needed to draw the notification at the camera", overlayChip) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } as LinearLayout
        setup.addView(accessRow)
        setup.addView(divider())
        setup.addView(overlayRow)
        setup.addView(divider())
        setup.addView(tileRow("🔋", 0xFFF2994A.toInt(), "Battery: Unrestricted",
            "Keeps notifications instant in the background", null) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        col.addView(setup)

        // --- Customize ---
        col.addView(sectionHeader("Customize"))
        val tools = card()
        tools.addView(tileRow("🎛️", 0xFFA98BFF.toInt(), "Settings & live preview",
            "Animation, glass, colours, buttons", null) {
            startActivity(Intent(this, SettingsActivity::class.java))
        })
        tools.addView(divider())
        tools.addView(tileRow("📱", 0xFF2BB673.toInt(), "Apps",
            "Choose which apps are allowed to pop up", null) {
            startActivity(Intent(this, AppsActivity::class.java))
        })
        tools.addView(divider())
        tools.addView(tileRow("🧪", 0xFFFF7AC8.toInt(), "Test lab",
            "Fake Telegram, WhatsApp and SMS notifications", null) {
            startActivity(Intent(this, TestActivity::class.java))
        })
        col.addView(tools)

        col.addView(label(
            "Tip: on Samsung turn off the system pop-up so you don't see two\n" +
                "(Settings → Notifications → Notification pop-up style → Brief).",
            12.5f, th.sub
        ).apply { setPadding(dpI(8f), dpI(18f), dpI(8f), 0) })

        setPage(scroller(col))
    }

    private fun setChip(chip: TextView, row: LinearLayout, on: Boolean) {
        chip.text = if (on) "✓ On" else "Off"
        val c = if (on) th.ok else th.bad
        chip.setTextColor(c)
        chip.background = th.round(th.alpha(c, 0x26), 12f)
    }

    override fun onResume() {
        super.onResume()
        val access = NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)
        val overlay = Settings.canDrawOverlays(this)
        setChip(accessChip, accessRow, access)
        setChip(overlayChip, overlayRow, overlay)
        summary.text = when {
            access && overlay -> "All set — notifications from every app will now flow out of the camera."
            else -> "Turn on the two switches below to get started."
        }
    }
}
