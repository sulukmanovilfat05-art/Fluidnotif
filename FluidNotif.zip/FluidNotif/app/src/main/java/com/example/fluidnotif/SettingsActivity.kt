package com.example.fluidnotif

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView

class SettingsActivity : BaseActivity() {

    private lateinit var sp: SharedPreferences
    private lateinit var preview: PreviewView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sp = getSharedPreferences("fluid", Context.MODE_PRIVATE)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(topBar("Settings"))

        // Live preview stays pinned on top while you tune the options below.
        preview = PreviewView(this, cycle = false)
        root.addView(preview, LinearLayout.LayoutParams(MATCH, dpI(232f)).apply {
            setMargins(dpI(16f), dpI(2f), dpI(16f), dpI(6f))
        })

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpI(16f), 0, dpI(16f), dpI(36f))
        }
        buildOptions(col)
        root.addView(scroller(col), LinearLayout.LayoutParams(MATCH, 0, 1f))

        setPage(root)
    }

    // ---- Settings UI generated from Opts.list ----
    private fun buildOptions(col: LinearLayout) {
        var lastSection = ""
        var group: LinearLayout? = null
        for (o in Opts.list) {
            if (o.section != lastSection) {
                lastSection = o.section
                col.addView(sectionHeader(o.section))
                group = card().also { col.addView(it) }
            } else {
                group?.addView(divider())
            }
            val target = group ?: continue
            when (o.type) {
                T.SWITCH -> target.addView(switchRow(o.title, Opts.b(sp, o.key)) { v ->
                    sp.edit().putInt(o.key, if (v) 1 else 0).apply()
                    preview.replay(250)
                })
                T.SLIDER -> target.addView(sliderRow(o, Opts.i(sp, o.key)) { v ->
                    sp.edit().putInt(o.key, v).apply()
                    preview.replay(320)
                })
                T.CHOICE -> {
                    val idx = Opts.i(sp, o.key).coerceIn(0, o.choices.size - 1)
                    var row: LinearLayout? = null
                    row = choiceRow(o.title, o.choices[idx], Opts.EDGE_COLORS.getOrNull(idx)?.second) {
                        AlertDialog.Builder(this)
                            .setTitle(o.title)
                            .setItems(o.choices.toTypedArray()) { _, which ->
                                sp.edit().putInt(o.key, which).apply()
                                row?.let { r ->
                                    (r.getChildAt(r.childCount - 1) as TextView).text = "${o.choices[which]}  ›"
                                    if (r.childCount == 3) {
                                        (r.getChildAt(1).background as GradientDrawable)
                                            .setColor(Opts.EDGE_COLORS[which].second)
                                    }
                                }
                                preview.replay(250)
                            }.show()
                    }
                    target.addView(row)
                }
            }
        }

        col.addView(sectionHeader("More"))
        val more = card()
        more.addView(tileRow("📱", 0xFF2BB673.toInt(), "Apps", "Choose which apps can pop up", null) {
            startActivity(Intent(this, AppsActivity::class.java))
        })
        more.addView(divider())
        more.addView(tileRow("🧪", 0xFFFF7AC8.toInt(), "Test lab", "Try fake notifications", null) {
            startActivity(Intent(this, TestActivity::class.java))
        })
        more.addView(divider())
        more.addView(tileRow("↺", 0xFFE5483D.toInt(), "Reset all settings", "Back to the defaults", null) {
            AlertDialog.Builder(this)
                .setTitle("Reset all settings?")
                .setPositiveButton("Reset") { _, _ ->
                    sp.edit().clear().apply()
                    recreate()
                }
                .setNegativeButton("Cancel", null)
                .show()
        })
        col.addView(more)
    }
}
