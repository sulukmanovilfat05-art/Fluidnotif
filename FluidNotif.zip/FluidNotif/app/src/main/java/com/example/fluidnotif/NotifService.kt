package com.example.fluidnotif

import android.app.Notification
import android.app.NotificationManager
import android.app.RemoteInput
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Listens to EVERY app's notifications (Telegram, WhatsApp, SMS, mail, ...) and hands them
 * to the overlay. Chat apps use MessagingStyle, so the newest message + sender is extracted
 * from there instead of the generic "3 new messages" text.
 */
class NotifService : NotificationListenerService() {

    private val skipCategories = setOf(
        Notification.CATEGORY_TRANSPORT, Notification.CATEGORY_PROGRESS,
        Notification.CATEGORY_SERVICE, Notification.CATEGORY_SYSTEM,
        Notification.CATEGORY_STATUS
    )

    /** key -> signature of what we already showed, so silent re-posts don't pop up again. */
    private val seen = HashMap<String, Int>()

    override fun onListenerDisconnected() {
        try { requestRebind(ComponentName(this, NotifService::class.java)) } catch (_: Exception) {}
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        seen.remove(sbn.key)
    }

    @Suppress("DEPRECATION")
    private fun readMessages(ex: Bundle): List<Notification.MessagingStyle.Message> {
        val arr = ex.getParcelableArray(Notification.EXTRA_MESSAGES) ?: return emptyList()
        return try {
            Notification.MessagingStyle.Message.getMessagesFromBundleArray(arr).orEmpty()
        } catch (e: Exception) {
            emptyList()
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val n = sbn.notification
        val st = Style(getSharedPreferences("fluid", Context.MODE_PRIVATE))

        if (sbn.packageName in st.blocked) return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (st.skipOngoing && (sbn.isOngoing || n.category in skipCategories)) return

        // Respect the system's own verdict: silent / Do Not Disturb.
        try {
            val rm = NotificationListenerService.Ranking()
            if (currentRanking.getRanking(sbn.key, rm)) {
                if (!st.silent && rm.importance < NotificationManager.IMPORTANCE_DEFAULT) return
                if (st.dnd && !rm.matchesInterruptionFilter()) return
            }
        } catch (_: Exception) {}

        val ex = n.extras
        var title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        var text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty()
        var meta = "now"
        var avatarIcon: Icon? = try { n.getLargeIcon() } catch (_: Exception) { null }

        // Chat apps (Telegram, WhatsApp, Messages, Signal, ...): take the newest message.
        val msgs = readMessages(ex)
        if (msgs.isNotEmpty()) {
            val last = msgs.last()
            val body = last.text?.toString().orEmpty()
            val sender = last.senderPerson?.name?.toString()
            val conv = ex.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString()
            if (body.isNotEmpty()) {
                if (!conv.isNullOrEmpty()) {
                    title = conv
                    text = if (!sender.isNullOrEmpty()) "$sender: $body" else body
                } else {
                    if (!sender.isNullOrEmpty()) title = sender
                    text = body
                }
            }
            if (msgs.size > 1) meta = "${msgs.size} messages"
            if (avatarIcon == null) avatarIcon = last.senderPerson?.icon
        }

        if (title.isEmpty() && text.isEmpty()) return

        // Same notification re-posted (read receipts, progress of a reply, ...): don't pop up again.
        val sig = (title + "\u0000" + text).hashCode()
        if (seen[sbn.key] == sig) return
        if (n.flags and Notification.FLAG_ONLY_ALERT_ONCE != 0 && seen.containsKey(sbn.key)) {
            seen[sbn.key] = sig
            return
        }
        if (seen.size > 300) seen.clear()
        seen[sbn.key] = sig

        val pm = packageManager
        val pkg = sbn.packageName
        val appName = try {
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) { pkg }

        val acts = n.actions.orEmpty()
        val replyAct = acts.firstOrNull {
            it.semanticAction == Notification.Action.SEMANTIC_ACTION_REPLY && !it.remoteInputs.isNullOrEmpty()
        } ?: acts.firstOrNull { !it.remoteInputs.isNullOrEmpty() }
        val readAct = acts.firstOrNull {
            it.semanticAction == Notification.Action.SEMANTIC_ACTION_MARK_AS_READ ||
                it.title?.contains("read", ignoreCase = true) == true ||
                it.title?.contains("прочит", ignoreCase = true) == true
        }
        val ri = replyAct?.remoteInputs?.let { arr -> arr.firstOrNull { it.allowFreeFormInput } ?: arr.firstOrNull() }
        val app = applicationContext
        val finalAvatar = avatarIcon

        val data = NotifData(
            appName = appName,
            icon = { try { pm.getApplicationIcon(pkg) } catch (e: Exception) { null } },
            title = title,
            text = text,
            canReply = ri != null,
            onOpen = {
                sendPending(app, n.contentIntent)
                try { cancelNotification(sbn.key) } catch (_: Exception) {}
            },
            onRead = {
                sendPending(app, readAct?.actionIntent)
                try { cancelNotification(sbn.key) } catch (_: Exception) {}
            },
            onReply = { reply ->
                try {
                    if (ri != null && replyAct != null) {
                        val i = Intent()
                        val b = Bundle().apply { putCharSequence(ri.resultKey, reply) }
                        RemoteInput.addResultsToIntent(arrayOf(ri), i, b)
                        sendPending(app, replyAct.actionIntent, i)
                    }
                } catch (_: Exception) {}
                try { cancelNotification(sbn.key) } catch (_: Exception) {}
            },
            avatar = { try { finalAvatar?.loadDrawable(app) } catch (e: Exception) { null } },
            meta = meta,
            key = sbn.key
        )
        OverlayController.show(app, data)
    }
}
