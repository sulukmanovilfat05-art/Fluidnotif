package com.example.fluidnotif

import android.app.ActivityOptions
import android.app.PendingIntent
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.os.Build
import android.view.View
import android.view.ViewGroup
import kotlin.math.min

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun Context.dpF(v: Float): Float = v * resources.displayMetrics.density
fun Context.dpI(v: Float): Int = (v * resources.displayMetrics.density).toInt()
fun View.dpF(v: Float): Float = context.dpF(v)
fun View.dpI(v: Float): Int = context.dpI(v)
fun lerp(a: Float, b: Float, t: Float): Float = a + (b - a) * t

/**
 * Camera geometry in the card view's own coordinates:
 * (cx, cy) = centre of the camera, r = radius of the white ring around it,
 * top = y where the expanded card starts.
 */
class Geo(val cx: Float, val cy: Float, val r: Float, val top: Float)

/** Everything the overlay needs to show one notification (real or fake). */
data class NotifData(
    val appName: String,
    val icon: () -> Drawable?,
    val title: String,
    val text: String,
    val canReply: Boolean,
    val onOpen: () -> Unit,
    val onRead: () -> Unit,
    val onReply: (String) -> Unit,
    /** Contact photo / large icon, if the app provided one. */
    val avatar: () -> Drawable? = { null },
    /** Text after the app name in the header, e.g. "now" or "3 messages". */
    val meta: String = "now",
    /** Same key = same conversation: a newer one replaces the older one on screen. */
    val key: String? = null,
    /** Incoming call: the panel shows Answer / Decline instead of Reply / Mark as read. */
    val isCall: Boolean = false,
    val onAnswer: () -> Unit = {},
    val onDecline: () -> Unit = {}
)

/** Sends a PendingIntent in a way that is allowed to start an activity from the background. */
fun sendPending(ctx: Context, pi: PendingIntent?, fillIn: android.content.Intent? = null) {
    if (pi == null) return
    try {
        val opts = ActivityOptions.makeBasic()
        if (Build.VERSION.SDK_INT >= 34) {
            opts.setPendingIntentBackgroundActivityStartMode(ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED)
        }
        pi.send(ctx, 0, fillIn, null, null, null, opts.toBundle())
    } catch (_: Exception) {
        try { pi.send(ctx, 0, fillIn) } catch (_: Exception) {}
    }
}

/** Simple round letter icon used for fake notifications. */
class LetterIcon(private val c: Int, private val letter: String) : Drawable() {
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = c }
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        val r = min(b.width(), b.height()) / 2f
        canvas.drawCircle(b.exactCenterX(), b.exactCenterY(), r, bg)
        tp.textSize = r * 1.05f
        canvas.drawText(letter, b.exactCenterX(), b.exactCenterY() - (tp.ascent() + tp.descent()) / 2f, tp)
    }

    override fun setAlpha(alpha: Int) { bg.alpha = alpha }
    override fun setColorFilter(colorFilter: ColorFilter?) { bg.colorFilter = colorFilter }
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
