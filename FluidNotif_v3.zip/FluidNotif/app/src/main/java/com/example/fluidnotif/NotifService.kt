package com.example.fluidnotif

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Listens to EVERY app's notifications (Telegram, WhatsApp, SMS, mail, ...) and hands them
 * to the overlay. Chat apps use MessagingStyle, so the newest message + sender is extracted
 * from there instead of the generic "3 new messages" text. Ringing calls get Answer / Decline.
 */
class NotifService : NotificationListenerService() {

    private val skipCategories = setOf(
        Notification.CATEGORY_TRANSPORT, Notification.CATEGORY_PROGRESS,
        Notification.CATEGORY_SERVICE, Notification.CATEGORY_SYSTEM,
        Notification.CATEGORY_STATUS
    )

    /** key -> signature of what we already showed, so silent re-posts don't pop up again. */
    private val seen = HashMap<String, Int>()

    /** keys of ringing-call notifications currently shown, so the panel closes when the call ends. */
    private val callKeys = HashSet<String>()

    private val answerWords = listOf(
        "answer", "accept", "pick up", "ответ", "принять", "принят", "взять",
        "répondre", "accepter", "antworten", "annehmen", "responder", "aceptar", "atender", "rispondi"
    )
    private val declineWords = listOf(
        "decline", "reject", "hang up", "hangup", "end call", "dismiss", "отклон", "сброс", "отбой", "завершить",
        "refuser", "raccrocher", "ablehnen", "auflegen", "rechazar", "colgar", "recusar", "rifiuta"
    )

    @Suppress("DEPRECATION")
    private fun pendingExtra(ex: Bundle, key: String): PendingIntent? =
        try { ex.getParcelable<PendingIntent>(key) } catch (_: Exception) { null }

    override fun onListenerDisconnected() {
        try { requestRebind(ComponentName(this, NotifService::class.java)) } catch (_: Exception) {}
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        seen.remove(sbn.key)
        if (callKeys.remove(sbn.key)) OverlayController.dismissKey(sbn.key)
    }

    @Suppress("DEPRECATION")
    private fun readMessages(ex: Bundle): List<Notification.MessagingStyle.Message> {
        val arr = ex.getParcelableArray(Notification.EXTRA_MESSAGES) ?: return emptyList()
        return try {
            Notification.MessagingStyle.Message.getMessagesFromBundleArray(arr).orEmpty()
        } catch (e: Exception) {
            emptyList()
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            handle(sbn)
        } catch (e: Exception) {
            NotifLog.add("ERROR ${sbn.packageName}: ${e.javaClass.simpleName} ${e.message}")
        }
    }

    private fun handle(sbn: StatusBarNotification) {
        val n = sbn.notification
        val st = Style(getSharedPreferences("fluid", Context.MODE_PRIVATE))
        val pkg = sbn.packageName
        val ex = n.extras
        val acts = n.actions.orEmpty()

        val template = ex.getString(Notification.EXTRA_TEMPLATE).orEmpty()
        val callType = ex.getInt(Notification.EXTRA_CALL_TYPE, 0)
        val desc = pkg + " cat=" + (n.category ?: "-") +
            " tmpl=" + template.substringAfterLast('$').ifEmpty { "-" } +
            " type=" + callType +
            " ongoing=" + (if (sbn.isOngoing) "Y" else "N") +
            " fsi=" + (if (n.fullScreenIntent != null) "Y" else "N") +
            " actions=[" + acts.joinToString("|") { it.title?.toString() ?: "?" } + "]"
        fun done(why: String) = NotifLog.add("$why\n   $desc")

        if (pkg in st.blocked) { done("SKIP app is switched off"); return }
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) { done("SKIP group summary"); return }

        // ---------- Calls (WhatsApp, Telegram, Phone, ...): find Answer / Decline ----------
        val callish = n.category == Notification.CATEGORY_CALL ||
            template.endsWith("CallStyle") || callType != 0
        var answerPi: PendingIntent? = null
        var declinePi: PendingIntent? = null
        var answerLabel = "Answer"
        var declineLabel = "Decline"
        val unmatched = ArrayList<Notification.Action>()
        var incoming = false
        if (callish) {
            answerPi = pendingExtra(ex, Notification.EXTRA_ANSWER_INTENT)
            declinePi = pendingExtra(ex, Notification.EXTRA_DECLINE_INTENT)
            for (a in acts) {
                val t = a.title?.toString().orEmpty()
                val tl = t.lowercase()
                if (answerWords.any { tl.contains(it) }) {
                    if (answerPi == null) answerPi = a.actionIntent
                    if (t.isNotEmpty()) answerLabel = t
                } else if (declineWords.any { tl.contains(it) }) {
                    if (declinePi == null) declinePi = a.actionIntent
                    if (t.isNotEmpty()) declineLabel = t
                } else {
                    unmatched.add(a)
                }
            }
            val ongoingType = callType == 2 || callType == 3 // ongoing / screening
            incoming = !ongoingType && (answerPi != null || callType == 1)
            if (!incoming && !ongoingType && answerPi == null && n.fullScreenIntent != null && unmatched.size == 2) {
                // Unknown wording, but it ring-style (full screen) with two buttons: decline first, answer second.
                declinePi = unmatched[0].actionIntent
                answerPi = unmatched[1].actionIntent
                declineLabel = unmatched[0].title?.toString() ?: declineLabel
                answerLabel = unmatched[1].title?.toString() ?: answerLabel
                incoming = true
            }
            if (!incoming) {
                if (callKeys.remove(sbn.key)) OverlayController.dismissKey(sbn.key)
                if (ongoingType || sbn.isOngoing || declinePi != null) {
                    done("SKIP call in progress"); return
                }
                // otherwise (e.g. a missed call) it is shown like any normal notification
            }
        }
        if (incoming && !st.callOn) { done("SKIP incoming calls are switched off in settings"); return }

        if (!incoming && st.skipOngoing && (sbn.isOngoing || n.category in skipCategories)) {
            done("SKIP ongoing / system notification"); return
        }

        // Respect the system's own verdict: silent / Do Not Disturb.
        try {
            val rm = NotificationListenerService.Ranking()
            if (currentRanking.getRanking(sbn.key, rm)) {
                if (!incoming && !st.silent && rm.importance < NotificationManager.IMPORTANCE_DEFAULT) {
                    done("SKIP silent notification (importance ${rm.importance})"); return
                }
                if (st.dnd && !rm.matchesInterruptionFilter()) { done("SKIP Do Not Disturb"); return }
            }
        } catch (_: Exception) {}

        var title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        var text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty()
        var meta = "now"
        var avatarIcon: Icon? = try { n.getLargeIcon() } catch (_: Exception) { null }

        // Chat apps (Telegram, WhatsApp, Messages, Signal, ...): take the newest message.
        val msgs = readMessages(ex)
        if (msgs.isNotEmpty() && !incoming) {
            val last = msgs.last()
            val body = last.text?.toString().orEmpty()
            val sender = last.senderPerson?.name?.toString()
            val conv = ex.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString()
            if (body.isNotEmpty()) {
                if (!conv.isNullOrEmpty()) {
                    title = conv
                    text = if (!sender.isNullOrEmpty()) "$sender: $body" else body
                } else {
                    if (!sender.isNullOrEmpty()) title = sender
                    text = body
                }
            }
            if (msgs.size > 1) meta = "${msgs.size} messages"
            if (avatarIcon == null) avatarIcon = last.senderPerson?.icon
        }

        if (incoming) {
            if (text.isEmpty()) text = "Incoming call"
            meta = "calling"
            if (avatarIcon == null) {
                val person = try {
                    @Suppress("DEPRECATION")
                    ex.getParcelable<android.app.Person>(Notification.EXTRA_CALL_PERSON)
                } catch (_: Exception) { null }
                avatarIcon = person?.icon
                if (title.isEmpty()) title = person?.name?.toString().orEmpty()
            }
        }
        if (title.isEmpty() && text.isEmpty()) { done("SKIP empty notification"); return }

        if (incoming) {
            // A ringing call re-posts itself many times: show the panel only once per call.
            if (!callKeys.add(sbn.key)) { done("SKIP call panel already on screen"); return }
        } else {
            // Same notification re-posted (read receipts, progress of a reply, ...): don't pop up again.
            val sig = (title + "\u0000" + text).hashCode()
            if (seen[sbn.key] == sig) { done("SKIP same as before"); return }
            if (n.flags and Notification.FLAG_ONLY_ALERT_ONCE != 0 && seen.containsKey(sbn.key)) {
                seen[sbn.key] = sig
                done("SKIP update (alert once)"); return
            }
            if (seen.size > 300) seen.clear()
            seen[sbn.key] = sig
        }

        val pm = packageManager
        val appName = try {
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) { pkg }

        val replyAct = acts.firstOrNull {
            it.semanticAction == Notification.Action.SEMANTIC_ACTION_REPLY && !it.remoteInputs.isNullOrEmpty()
        } ?: acts.firstOrNull { !it.remoteInputs.isNullOrEmpty() }
        val readAct = acts.firstOrNull {
            it.semanticAction == Notification.Action.SEMANTIC_ACTION_MARK_AS_READ ||
                it.title?.contains("read", ignoreCase = true) == true ||
                it.title?.contains("прочит", ignoreCase = true) == true
        }
        val ri = replyAct?.remoteInputs?.let { arr -> arr.firstOrNull { it.allowFreeFormInput } ?: arr.firstOrNull() }
        val app = applicationContext
        val finalAvatar = avatarIcon
        val ansPi = answerPi
        val decPi = declinePi
        val isCall = incoming

        val data = NotifData(
            appName = appName,
            icon = { try { pm.getApplicationIcon(pkg) } catch (e: Exception) { null } },
            title = title,
            text = text,
            canReply = ri != null && !isCall,
            onOpen = {
                sendPending(app, n.contentIntent ?: n.fullScreenIntent)
                if (!isCall) { try { cancelNotification(sbn.key) } catch (_: Exception) {} }
            },
            onRead = {
                sendPending(app, readAct?.actionIntent)
                try { cancelNotification(sbn.key) } catch (_: Exception) {}
            },
            onReply = { reply ->
                try {
                    if (ri != null && replyAct != null) {
                        val i = Intent()
                        val b = Bundle().apply { putCharSequence(ri.resultKey, reply) }
                        RemoteInput.addResultsToIntent(arrayOf(ri), i, b)
                        sendPending(app, replyAct.actionIntent, i)
                    }
                } catch (_: Exception) {}
                try { cancelNotification(sbn.key) } catch (_: Exception) {}
            },
            avatar = { try { finalAvatar?.loadDrawable(app) } catch (e: Exception) { null } },
            meta = meta,
            key = sbn.key,
            isCall = isCall,
            onAnswer = ansPi?.let { p -> { sendPending(app, p) } },
            onDecline = decPi?.let { p -> { sendPending(app, p) } },
            answerLabel = answerLabel,
            declineLabel = declineLabel
        )
        done(if (isCall) "SHOWN as incoming CALL" else "SHOWN")
        OverlayController.show(app, data)
    }
}
