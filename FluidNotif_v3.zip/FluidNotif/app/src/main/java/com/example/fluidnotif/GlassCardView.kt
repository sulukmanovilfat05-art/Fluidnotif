package com.example.fluidnotif

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.Typeface
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.dynamicanimation.animation.FloatPropertyCompat
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * Liquid glass notification.
 *
 * The whole thing is ONE shape: a ring around the camera + a rounded card, joined by a smooth
 * concave "neck" (metaball look). [progress] 0 = only the ring, 1 = fully expanded card.
 * Spring driven, may overshoot a little (> 1).
 *
 * The view starts at the very top of the screen (y = 0) so the ring around the camera can be
 * drawn inside it; the actual card starts at [Geo.top].
 */
class GlassCardView(
    context: Context,
    d: NotifData,
    private val st: Style,
    private val geo: Geo
) : FrameLayout(context) {

    companion object {
        val PROGRESS = object : FloatPropertyCompat<GlassCardView>("progress") {
            override fun getValue(o: GlassCardView) = o.progress
            override fun setValue(o: GlassCardView, value: Float) { o.progress = value }
        }
    }

    /** 0 = ring only, 1 = expanded. */
    var progress = 0f
        set(v) {
            field = v
            applyContent()
            invalidate()
        }

    /** Opacity of the whole liquid shape (the ring pops in before the card grows). */
    var ringAlpha = 0f
        set(v) {
            field = v
            invalidate()
        }

    /** Extra multiplier for the text/buttons content (used to fade it out first when closing). */
    var contentFade = 1f
        set(v) {
            field = v
            applyContent()
        }

    private val extraBottom = dpI(14f) // room for the spring overshoot
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val hair = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(0.8f)
        color = if (st.dark) 0x26FFFFFF else 0x80FFFFFF.toInt()
    }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(st.edgeWDp)
    }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(st.edgeWDp * 4f)
    }
    private val rect = RectF()
    private val shape = Path()
    private val pA = Path()
    private val pB = Path()
    private val pNeck = Path()
    private val pC1 = Path()
    private val pC2 = Path()
    private val content = LinearLayout(context)
    private var lastBlur = -1f
    private var builtP = -1f
    private var builtW = -1
    private var builtH = -1

    private fun withA(c: Int, a: Int): Int = (c and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

    private fun circleClip(v: View) {
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setOval(0, 0, view.width, view.height)
            }
        }
        v.clipToOutline = true
    }

    init {
        setWillNotDraw(false)

        val cHeader = if (st.dark) 0xFFB0B0BA.toInt() else 0xFF6B6B73.toInt()
        val cTitle = if (st.dark) 0xFFF4F4F8.toInt() else 0xFF121216.toInt()
        val cBody = if (st.dark) 0xFFD0D0D8.toInt() else 0xFF4A4A52.toInt()
        val s = st.textScale

        content.orientation = LinearLayout.HORIZONTAL
        content.gravity = Gravity.CENTER_VERTICAL
        content.setPadding(dpI(16f), dpI(14f), dpI(16f), dpI(14f))

        // Avatar (contact photo) with a small app badge, or just the app icon.
        val isz = dpI(st.iconDp)
        val av = if (st.avatar) d.avatar() else null
        val extra = if (av != null) dpI(4f) else 0
        val iconFrame = FrameLayout(context)
        val main = ImageView(context).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setImageDrawable(av ?: d.icon())
            circleClip(this)
        }
        iconFrame.addView(main, FrameLayout.LayoutParams(isz, isz, Gravity.TOP or Gravity.START))
        if (av != null) {
            val bsz = (isz * 0.46f).toInt()
            val badge = ImageView(context).apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                setImageDrawable(d.icon())
                setBackgroundColor(if (st.dark) 0xFF2A2A30.toInt() else 0xFFFFFFFF.toInt())
                setPadding(dpI(1f), dpI(1f), dpI(1f), dpI(1f))
                circleClip(this)
            }
            iconFrame.addView(badge, FrameLayout.LayoutParams(bsz, bsz, Gravity.BOTTOM or Gravity.END))
        }
        content.addView(iconFrame, LinearLayout.LayoutParams(isz + extra, isz + extra))

        val col = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        col.addView(TextView(context).apply {
            text = "${d.appName} · ${d.meta}"
            textSize = 12f * s
            setTextColor(cHeader)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        })
        col.addView(TextView(context).apply {
            text = d.title
            textSize = 15.5f * s
            setTextColor(cTitle)
            setTypeface(typeface, Typeface.BOLD)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        })
        col.addView(TextView(context).apply {
            text = if (st.hide) "Message hidden" else d.text
            textSize = 14f * s
            setTextColor(cBody)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        })
        val lp = LinearLayout.LayoutParams(0, WRAP, 1f)
        lp.marginStart = dpI(12f)
        content.addView(col, lp)

        addView(content, LayoutParams(MATCH, WRAP).apply {
            topMargin = geo.top.toInt()
            bottomMargin = extraBottom
        })
        applyContent()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        // Milky glass: slightly lavender on the left, warmer/whiter on the right (like the reference).
        val c1 = if (st.dark) 0x2E2E38 else 0xE6E9F6
        val c2 = if (st.dark) 0x1C1C22 else 0xFFFBF8
        fill.shader = LinearGradient(
            0f, 0f, w.toFloat(), 0f,
            withA(c1, st.glassAlpha), withA(c2, (st.glassAlpha * 0.94f).toInt()),
            Shader.TileMode.CLAMP
        )
        val edge = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), st.c1, st.c2, Shader.TileMode.CLAMP)
        glow.shader = edge
        stroke.shader = edge
    }

    private fun applyContent() {
        // Content fades in and un-blurs during the second half of the expansion.
        val a = ((progress - 0.35f) / 0.5f).coerceIn(0f, 1f) * contentFade
        content.alpha = a
        val r = (1f - a) * dpF(st.textBlurDp)
        // Re-creating the blur on every frame is what made the animation stutter:
        // only update it when it changed by a visible step.
        val step = dpF(1.5f)
        val q = if (r > 0.5f) Math.round(r / step) * step else 0f
        if (q != lastBlur) {
            lastBlur = q
            content.setRenderEffect(
                if (q > 0f) RenderEffect.createBlurEffect(q, q, Shader.TileMode.CLAMP) else null
            )
        }
    }

    /** Ring + rounded card + smooth concave neck between them. */
    private fun buildShape(rc: RectF, radius: Float) {
        val cx = geo.cx
        val cy = geo.cy
        val rr = geo.r
        pA.reset(); pA.addCircle(cx, cy, rr, Path.Direction.CW)
        pB.reset(); pB.addRoundRect(rc, radius, radius, Path.Direction.CW)
        shape.reset()
        shape.op(pA, pB, Path.Op.UNION)

        val t = rc.top
        if (!st.neck || rc.width() < rr * 3f || rc.height() < rr || t <= cy) return

        // Fillet circles of radius f: tangent to the card's top edge and to the ring.
        var f = max(rr * 0.65f, (t - cy - rr) / 2f + dpF(1.5f))
        var dx = -1f
        for (i in 0..6) {
            val dy = t - f - cy
            val sum = rr + f
            if (sum * sum >= dy * dy) {
                val d2 = sqrt(sum * sum - dy * dy)
                if (cx - d2 >= rc.left + radius && cx + d2 <= rc.right - radius) { dx = d2; break }
            }
            f *= 0.8f
        }
        if (dx < 0f) return

        val fl = cx - dx
        val fr = cx + dx
        pNeck.reset()
        pNeck.moveTo(cx, cy)
        pNeck.lineTo(fl, t - f)
        pNeck.lineTo(fl, t + dpF(2f))
        pNeck.lineTo(fr, t + dpF(2f))
        pNeck.lineTo(fr, t - f)
        pNeck.close()
        pC1.reset(); pC1.addCircle(fl, t - f, f, Path.Direction.CW)
        pC2.reset(); pC2.addCircle(fr, t - f, f, Path.Direction.CW)
        pNeck.op(pC1, Path.Op.DIFFERENCE)
        pNeck.op(pC2, Path.Op.DIFFERENCE)
        shape.op(pNeck, Path.Op.UNION)
    }

    override fun onDraw(canvas: Canvas) {
        if (ringAlpha <= 0.01f) return
        val p = progress.coerceAtLeast(0f)
        val pc = min(p, 1f)
        val w = width.toFloat()
        val fullB = height.toFloat() - extraBottom

        // The card grows out of a little blob under the camera.
        val s = (p / 0.14f).coerceIn(0f, 1f)
        val bw = geo.r * 2.0f * s
        val bh = geo.r * 1.7f * s
        val bcy = geo.cy + geo.r * (0.7f + 0.5f * s) // stays attached to the ring while it grows
        val pw = pc.pow(0.85f)            // width leads a little...
        val ph = p                        // ...height follows (and may overshoot = bounce)
        rect.set(
            lerp(geo.cx - bw / 2f, 0f, pw),
            lerp(bcy - bh / 2f, geo.top, ph),
            lerp(geo.cx + bw / 2f, w, pw),
            lerp(bcy + bh / 2f, fullB, ph)
        )
        val radius = min(dpF(st.cornerDp), min(rect.width(), rect.height()) / 2f)
        // The shape only depends on progress and size: don't redo the path maths for a plain fade.
        if (p != builtP || width != builtW || height != builtH) {
            buildShape(rect, radius)
            builtP = p; builtW = width; builtH = height
        }

        val a = (ringAlpha * 255f).toInt().coerceIn(0, 255)
        fill.alpha = a
        canvas.drawPath(shape, fill)
        hair.alpha = (a * (if (st.dark) 0.15f else 0.5f)).toInt()
        canvas.drawPath(shape, hair)

        if (st.edgeOn) {
            glow.alpha = (st.glowAlpha * ringAlpha).toInt()
            stroke.alpha = a
            canvas.drawPath(shape, glow)
            canvas.drawPath(shape, stroke)
        }
    }
}
